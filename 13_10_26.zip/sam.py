import tkinter as tk
from tkinter import ttk, messagebox
import psycopg2


DB_CONFIG = {
    "host" : "localhost",
    "user" : "postgres",
    "password" : "Wahf128lkr",
    "port" : "5432",
    "database" : "demo_1"
}

def perexod():
    katalog_f.pack_forget()
    registr_f.pack()

    


def get_users_fio(login):
    con = psycopg2.connect(**DB_CONFIG)
    try:
        cur = con.cursor()
        cur.execute('''select users_fam, users_name, users_otc, users_login
                    from users
                    where users_login =%s
                    ''', (login,))
        row = cur.fetchone()
        if row:
            return f"{row[0]}, {row[1]}, {row[2] or ''}".strip()
    except Exception as e:
        messagebox.showerror("Ошибка!", str(e))
    finally:
        cur.close()
        con.close()
    return None

def get_login():

    login = registr_e.get().strip()
    if not login:
        messagebox.showwarning("Ошибка!","Логин не найден!")
        return
    fio = get_users_fio(login)
    if fio:
        registr_f.pack_forget()
        katalog_f.pack()

        hi_label = tk.Label(katalog_f, text=f"Добро пожаловать, {fio} !", font=('Calibri',10))
        hi_label.grid(row=0, column=0, sticky="n")
    else:
        messagebox.showerror("Ошибка!","Пользователь не найден!")


window = tk.Tk()
window.geometry("1200x900")
window.title("Чудо-обувь")

katalog_f = tk.Frame(window)
katalog_f.pack()
exit_b = tk.Button(katalog_f, text="Войти", command=perexod)
exit_b.grid(column=0, row=0, padx=20, pady=20)



registr_f = tk.Frame(window)

reg_l = tk.Label(registr_f, text='Введите лоигн', font=('Calibri',14))
reg_l.grid(column=0, row=0)

registr_e = tk.Entry(registr_f)
registr_e.grid(column=0, row=1)
registr_b = tk.Button(registr_f, text='Войти', command=get_login)
registr_b.grid(column=0, row=2)


def katalog():
    try:
        con = psycopg2.connect(**DB_CONFIG)
        cur = con.cursor()
        cur.execute(
            '''select m.model_name, m.model_creator, m.model_opis, m.model_price, m.model_img
            from model m'''
        )
        rows = cur.fetchall()
        for pos, row in enumerate(rows):
            spisok_f = tk.Frame(katalog_f, )
            spisok_f.grid(column=0, row=pos+2, sticky='w', padx=5, pady=5)

            img_frame = tk.Frame(spisok_f, bg='grey',width=120, height=120)
            img_frame.pack_propagate
            img_frame.grid(column=0,row=0, pady=5, padx=5,)

            text_frame = tk.Frame(spisok_f,)
            text_frame.grid(column=1, row=0)

            model_l = tk.Label(text_frame, text=row[0] if row[0] else "Название не найдено.", font=('Calibri',12))
            model_l.grid(column=0, row=0)

            creat_l = tk.Label(text_frame, text=f"Производитель: {row[1]}" if row[1] else "Производитель не найден.", font=('Calibri',12))
            creat_l.grid(column=0, row=1)

            opis_l = tk.Label(text_frame, text=row[2] if row[2] else "Описание не найдено.", font=('Calibri',12))
            opis_l.grid(column=0, row=2)

            price_l = tk.Label(text_frame, text=f"{row[3]}.руб" if row[3] else "Цена не указана.", font=('Calibri',12))
            price_l.grid(column=1, row=2)

        cur.close()
        con.close()
    except Exception as e:
        messagebox.showerror("Ошибка БД", str(e))

katalog()









window.mainloop()






